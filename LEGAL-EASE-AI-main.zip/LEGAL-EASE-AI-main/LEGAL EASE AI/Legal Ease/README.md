# LegalEase

LegalEase is an AI-powered legal document draft generator.

## Technologies

- Python
- FastAPI
- Streamlit
- Google Gemini
- python-docx
- FPDF2
- Pillow
- Requests

## Features

- AI legal document generation
- Employment contracts
- NDAs
- Lease agreements
- Freelance contracts
- Editable document preview
- TXT export
- DOCX export
- PDF export
- Company branding
- Logo upload
- FastAPI backend
- Gemini integration
- Demo mode
- Automated tests

## Installation

Create a virtual environment:

```bash
python -m venv .venv
```
