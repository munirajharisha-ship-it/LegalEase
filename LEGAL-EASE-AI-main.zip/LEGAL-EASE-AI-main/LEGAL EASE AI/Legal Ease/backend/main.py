from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.routes import router


app = FastAPI(
	title="LegalEase API",
	description="AI-Powered Legal Document Generator API",
	version="1.0.0",
)


app.add_middleware(
	CORSMiddleware,
	allow_origins=["*"],
	allow_credentials=False,
	allow_methods=["*"],
	allow_headers=["*"],
)


app.include_router(router)


@app.get("/")
def root():
	return {
		"status": "ok",
		"service": "LegalEase API",
		"version": "1.0.0",
	}
